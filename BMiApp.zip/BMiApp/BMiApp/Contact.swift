//
//  Contact.swift
//  BMiApp
//
//  Created by Azamov Khumoyunbek on 18/02/25.
//

import Foundation

struct Contact {
    var firstName: String
    var lastName: String
}
