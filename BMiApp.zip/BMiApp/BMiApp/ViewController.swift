//
//  ViewController.swift
//  BMiApp
//
//  Created by Azamov Khumoyunbek on 11/02/25.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var boyLbl: UILabel!    
    @IBOutlet weak var kgLbl: UILabel!
    var contactN: Contact?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
    }
    
//    var dataToSend: String = "Hello from ViewController1"
    
    
   
        
        // segue orqali ikkinchi sahifaga o'tish
    var kg: Double = 0
    var boy: Double = 0
    var natMal = ""
    
    
        
    @IBAction func sliderValueHeight(_ sender: UISlider) {
        let heightValue = sender.value * 3
        boyLbl.text = String(format:"%.2f", heightValue) + "m"
//        boy = Double(String(format:"%.2f", heightValue)) ?? 0
        boy = Double(heightValue)
        print(heightValue)
    }
    
    @IBAction func sliderValueWeight(_ sender: UISlider) {
        let weightValue = sender.value * 200
        kgLbl.text = String(format:"%.2f", weightValue) + "kg"
//        kg = Double(String(format:"%.2f", weightValue)) ?? 0
        kg = Double(weightValue)
        
        print(weightValue)
    }
    
    @IBAction func nextButtonPressed(_ sender: UIButton) {
        
        var nat = kg/(boy * boy)
        
        var natija: Double = kg/(boy * boy)
        
        print(natija)
        
    
        
        if natija < 18.5 {
            natMal = "Ko'proq soglom ovqat yeng"
        } else if 18.5 < natija && natija < 24.9 {
            natMal = "Siz meyordasiz"
        } else if natija > 24.9 {
            natMal = "kamroq ovqat yeng"
        }
        
        contactN = Contact(firstName: String(format:"%.2f", natija), lastName: natMal)
        print(natija)
//
//        if let contact = contactN {
//            vc.contact = contact
//        } else {
//            print("contactN nil")
//        }
        
        performSegue(withIdentifier: "ToInfo", sender: self)
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        let vc2 = segue.destination as! SecondVC
        
        vc2.contact = contactN
        
    }
}



