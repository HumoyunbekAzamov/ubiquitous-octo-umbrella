//
//  SecondVC.swift
//  BMiApp
//
//  Created by Azamov Khumoyunbek on 14/02/25.
//

import UIKit

class SecondVC: UIViewController {

    @IBOutlet weak var natijaLbl: UILabel!
    
    @IBOutlet weak var malumotLbl: UILabel!
    
    var contact: Contact?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        natijaLbl.text = contact?.firstName
        malumotLbl.text = contact?.lastName
    }
    
    

}
