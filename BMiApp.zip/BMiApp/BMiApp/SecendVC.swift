//
//  SecendVC.swift
//  BMiApp
//
//  Created by Azamov Khumoyunbek on 12/02/25.
//

import UIKit

class SecendVC: UIViewController {

    @IBOutlet weak var natijaLbl: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }

}
