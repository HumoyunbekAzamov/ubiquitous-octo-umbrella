//
//  ViewController2.swift
//  BMiApp
//
//  Created by Azamov Khumoyunbek on 12/02/25.
//

import UIKit

class ViewController2: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
    }

}
